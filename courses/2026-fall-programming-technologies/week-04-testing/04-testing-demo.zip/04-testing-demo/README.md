# 4. óra — Tesztelés · mintaprojekt

Ez egy kész, működő Maven-projekt. Azért van, hogy legyen mit megnézned, és
hogy a saját beadandódhoz legyen mintád.

Nem kell semmit beállítanod. Csomagold ki, nyisd meg, futtasd.

---

## 1. Indulás

**IntelliJ IDEA-ban**

1. Csomagold ki a zip-et egy olyan mappába, aminek az útvonalában nincs ékezet és nincs szóköz.
2. `File → Open`, és válaszd ki a kicsomagolt **`04-testing-demo`** mappát.
   Ne a `pom.xml`-t, hanem a mappát.
3. Ha megkérdezi, hogy Maven projektként töltse-e be, mondj igent.
4. Várd meg, amíg a jobb alsó sarokban lefut a letöltés. Első alkalommal ez pár perc.

**Parancssorból**

```
cd 04-testing-demo
mvn clean verify
```

Ha a végén ezt látod, minden rendben:

```
[INFO] BUILD SUCCESS
```

Az első futás percekig tarthat, mert letölti a JUnitot, a Mockitót, a Jacocót és a
Checkstyle-t. Másodjára három másodperc.

---

## 2. Mi van benne?

```
04-testing-demo/
├── pom.xml                 a Maven konfiguráció, végig kommentelve
├── checkstyle.xml          stílusszabályok
└── src/
    ├── main/java/hu/nye/progtech/
    │   ├── GreetingGenerator.java    köszönést állít elő, van benne elágazás és hibaág
    │   ├── MessageSender.java        interfész, ezt fogjuk mockolni
    │   └── GreetingService.java      külső függőséget használ
    └── test/java/hu/nye/progtech/
        ├── GreetingGeneratorTest.java    7 teszt, JUnit 5
        └── GreetingServiceTest.java      3 teszt, Mockito
```

---

## 3. Hol találod meg, amiről az órán szó volt?

| Fogalom | Hol nézd meg |
|---|---|
| Given-When-Then szerkezet | `GreetingGeneratorTest`, minden teszt kommentelve van |
| Elnevezési konvenció | ugyanott: `testMethodShouldDoSomethingWhenCondition` |
| `@BeforeEach` | `GreetingGeneratorTest.setUp()` |
| `assertEquals` | az első tesztekben |
| `assertThrows` (hibaág tesztelése) | `testGenerateGreetingShouldThrowExceptionWhenLanguageIsNull` |
| `@ParameterizedTest` (egy teszt több bemenettel) | a `GreetingGeneratorTest` alján |
| Mockito: `mock`, `when`, `thenReturn` | `GreetingServiceTest` |
| Mockito: `verify` és `never()` | ugyanott, a harmadik teszt |
| Surefire, Jacoco, Checkstyle beállítása | `pom.xml`, blokkonként kommentelve |

---

## 4. Futtatás

**Egyetlen teszt:** kattints a teszt metódus melletti zöld háromszögre az IntelliJ-ben.

**Egy osztály összes tesztje:** az osztály neve melletti zöld háromszög.

**Minden, ahogy a build szerveren futna:**

```
mvn clean verify
```

Ez fordít, lefuttatja a teszteket, méri a lefedettséget, és ellenőrzi a stílust.

---

## 5. A lefedettségi riport

Build után nyisd meg böngészőben ezt a fájlt:

```
target/site/jacoco/index.html
```

Kattints bele a `GreetingGenerator` osztályba. Soronként színezi a kódot:

- **zöld** — ezen a soron futott teszt
- **piros** — ezen a soron nem futott teszt
- **sárga** — az elágazásnak csak az egyik ága futott le

Ez sokkal többet mond, mint egy százalékszám: pontosan megmutatja, hol nincs teszted.

---

## 6. Próbáld ki (négy kísérlet)

Érdemes mind a négyet végigcsinálni, mert ezekbe a helyzetekbe a beadandónál is
bele fogsz futni.

**1. Rontsd el szándékosan**
A `GreetingGeneratorTest`-ben írd át az egyik várt értéket valami rosszra, és futtasd
újra. Keresd meg a kimenetben az `expected` és a `but was` sorokat. Aztán írd vissza.

**2. Nézd meg, mi történik kevés teszttel**
Kommentezz ki két tesztet a `GreetingGeneratorTest`-ből, és futtasd újra a
`mvn clean verify`-t. A build el fog bukni, mert a lefedettség 80% alá esik:

```
Rule violated ... lines covered ratio is 0.6x, but expected minimum is 0.80
```

Ez nem hiba, hanem a beállított kapu. A `pom.xml`-ben a `<minimum>0.80</minimum>`
sornál lehet állítani.

**3. Írj egy hosszú sort**
Írj egy 150 karakteres sort a `GreetingGenerator`-ba. A Checkstyle figyelmeztetni fog,
de a build nem áll meg. Ez szándékos: a `pom.xml`-ben a `failOnViolation` értéke
`false`. Ha `true`-ra állítod, megáll.

**4. Írj egy új tesztet**
Egészítsd ki a `GreetingGenerator`-t egy új nyelvvel, és írj rá tesztet. Figyelj a
névre és a Given-When-Then szerkezetre.

---

## 7. Gyakori hibák

**Nem találja a JUnitot, piros minden import**
A Maven nem töltötte le a függőségeket. IntelliJ-ben a jobb oldali Maven ablakban
nyomd meg a körkörös nyilat (Reload).

**A tesztem nem fut le, pedig megírtam**
Két dolgot nézz meg. A teszt osztály a `src/test/java` mappában van-e, és a neve
`Test`-re végződik-e. Ha nem, a Maven meg sem találja.

**`Could not resolve dependencies`**
Nincs internet, vagy céges/iskolai hálózat blokkolja. Otthonról próbáld újra.

**A jacoco riport nem jött létre**
`mvn test`-et adtál ki `mvn clean verify` helyett. A riport a `verify` fázisban készül.

**`Rule violated ... expected minimum is 0.80`**
Kevés a teszt. Vagy írj még, vagy vedd lejjebb a küszöböt a `pom.xml`-ben.

**Mockito figyelmeztetés Java 21-en**
Kiír valamit arról, hogy önmagát csatolja ügynökként. Ez nem hiba, a tesztek lefutnak.

---

## 8. Házi feladat

Vedd elő a saját projektedet, és írj hozzá teszteket.

Amit be kell adni:

- JUnit 5 függőség, `test` scope-pal
- legalább öt értelmes teszt, Given-When-Then szerkezettel
- beszédes teszt metódusnevek a konvenció szerint
- legalább egy teszt a hibaágra (`assertThrows` vagy rossz bemenet)
- lefut az `mvn clean verify`

Amivel több lesz:

- Jacoco beállítva, 80%-os ellenőrzéssel
- Checkstyle beállítva, legalább figyelmeztető módban
- egy `@ParameterizedTest` több bemenettel
- egy Mockito-s teszt, ha van külső függőséged

A `pom.xml`-ből a teljes `<build>` blokkot át tudod másolni a saját projektedbe.

---

## 9. Ha elakadsz

Hozd a konkrét hibaüzenetet, **szó szerint úgy, ahogy megjelent**. Ne fogalmazd át,
és ne csak az utolsó sorát másold be: a Maven kimenetében az **első** hiba a fontos.

## Használt verziók

JUnit 5.10.2 · Mockito 5.14.2 · Surefire 3.2.5 · Jacoco 0.8.12 · Checkstyle 10.17.0

Java 21 szükséges hozzá.
