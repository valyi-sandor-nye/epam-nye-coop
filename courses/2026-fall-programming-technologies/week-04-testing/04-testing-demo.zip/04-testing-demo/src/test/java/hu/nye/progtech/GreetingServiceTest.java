package hu.nye.progtech;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Mockito-s pelda. A MessageSender egy kulso fuggoseg,
 * amit a tesztben nem akarunk igaziból elinditani.
 */
class GreetingServiceTest {

    private MessageSender sender;
    private GreetingService underTest;

    @BeforeEach
    void setUp() {
        // given - a hamis fuggoseg
        sender = mock(MessageSender.class);
        underTest = new GreetingService(new GreetingGenerator(), sender);
    }

    @Test
    void testGreetAndSendShouldReturnTrueWhenSenderSucceeds() {
        // given
        when(sender.send("Balazs", "Szia, Balazs!")).thenReturn(true);
        // when
        boolean result = underTest.greetAndSend("Balazs", "hu");
        // then
        assertTrue(result);
        verify(sender).send("Balazs", "Szia, Balazs!");
    }

    @Test
    void testGreetAndSendShouldReturnFalseWhenSenderFails() {
        // given
        when(sender.send(anyString(), anyString())).thenReturn(false);
        // when
        boolean result = underTest.greetAndSend("Bob", "en");
        // then
        assertFalse(result);
    }

    @Test
    void testGreetAndSendShouldNotSendAnythingWhenLanguageIsNull() {
        // given - when
        try {
            underTest.greetAndSend("Anna", null);
        } catch (IllegalArgumentException expected) {
            // a generator dob, ez a varhato viselkedes
        }
        // then - a kuldes soha nem tortent meg
        verify(sender, never()).send(anyString(), anyString());
    }
}
