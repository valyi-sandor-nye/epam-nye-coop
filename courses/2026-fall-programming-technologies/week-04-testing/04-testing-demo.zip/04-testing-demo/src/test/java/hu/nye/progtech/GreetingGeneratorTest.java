package hu.nye.progtech;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Figyeld meg:
 *  - az osztaly neve Test-re vegzodik, kulonben a Surefire meg sem talalja
 *  - a metodusnevek: testMethodShouldDoSomethingWhenCondition
 *  - minden tesztben ott a given - when - then szerkezet
 */
class GreetingGeneratorTest {

    private GreetingGenerator underTest;

    @BeforeEach
    void setUp() {
        // minden teszt elott ujra lefut, ezert fuggetlenek egymastol
        underTest = new GreetingGenerator();
    }

    @Test
    void testGenerateGreetingShouldReturnHungarianGreetingWhenLanguageIsHu() {
        // given
        String name = "Balazs";
        String language = "hu";
        // when
        String result = underTest.generateGreeting(name, language);
        // then
        assertEquals("Szia, Balazs!", result);
    }

    @Test
    void testGenerateGreetingShouldReturnEnglishGreetingWhenLanguageIsEn() {
        // given
        String name = "Bob";
        String language = "en";
        // when
        String result = underTest.generateGreeting(name, language);
        // then
        assertEquals("Hello, Bob!", result);
    }

    @Test
    void testGenerateGreetingShouldUseFallbackNameWhenNameIsBlank() {
        // given
        String name = "   ";
        // when
        String result = underTest.generateGreeting(name, "hu");
        // then
        assertEquals("Szia, Ismeretlen!", result);
    }

    @Test
    void testGenerateGreetingShouldUseFallbackNameWhenNameIsNull() {
        // given - when
        String result = underTest.generateGreeting(null, "hu");
        // then
        assertEquals("Szia, Ismeretlen!", result);
    }

    @Test
    @DisplayName("Ismeretlen nyelv eseten alapertelmezett koszonest ad")
    void testGenerateGreetingShouldReturnDefaultGreetingWhenLanguageIsUnknown() {
        // given - when
        String result = underTest.generateGreeting("Anna", "fr");
        // then
        assertEquals("Hi, Anna!", result);
    }

    @Test
    void testGenerateGreetingShouldThrowExceptionWhenLanguageIsNull() {
        // given - when - then
        assertThrows(IllegalArgumentException.class,
                () -> underTest.generateGreeting("Anna", null));
    }

    /**
     * Ugyanaz a teszt tobb bemenettel. Igy nem kell otszor lemasolni.
     */
    @ParameterizedTest
    @CsvSource({
            "hu, Szia",
            "HU, Szia",
            "en, Hello",
            "de, Hallo"
    })
    void testGenerateGreetingShouldUseCorrectPrefixWhenLanguageIsGiven(String language, String prefix) {
        // given - when
        String result = underTest.generateGreeting("Eva", language);
        // then
        assertEquals(prefix + ", Eva!", result);
    }
}
