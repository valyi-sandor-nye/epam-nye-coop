package hu.nye.progtech;

/**
 * Koszonest allit elo nev es nyelv alapjan.
 * Szandekosan van benne elagazas es hibaag, hogy legyen mit tesztelni.
 */
public class GreetingGenerator {

    private static final String FALLBACK_NAME = "Ismeretlen";

    public String generateGreeting(String name, String language) {
        if (language == null) {
            throw new IllegalArgumentException("A nyelv nem lehet null");
        }

        String safeName = (name == null || name.isBlank()) ? FALLBACK_NAME : name.trim();

        String greeting = switch (language.toLowerCase()) {
            case "hu" -> "Szia";
            case "en" -> "Hello";
            case "de" -> "Hallo";
            default -> "Hi";
        };

        return greeting + ", " + safeName + "!";
    }
}
