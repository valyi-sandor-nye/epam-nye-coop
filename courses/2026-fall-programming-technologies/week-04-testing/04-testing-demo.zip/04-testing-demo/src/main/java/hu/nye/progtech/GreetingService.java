package hu.nye.progtech;

/**
 * Osszerakja a koszonest, es elkuldi egy kulso szolgaltatassal.
 * Ez az osztaly a mockolas iskolapeldaja: van egy fuggosege,
 * amit kivulrol kap meg (constructor injection).
 */
public class GreetingService {

    private final GreetingGenerator generator;
    private final MessageSender sender;

    public GreetingService(GreetingGenerator generator, MessageSender sender) {
        this.generator = generator;
        this.sender = sender;
    }

    public boolean greetAndSend(String name, String language) {
        String message = generator.generateGreeting(name, language);
        return sender.send(name, message);
    }
}
