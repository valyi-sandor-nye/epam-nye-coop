package hu.nye.progtech;

/**
 * Kulso fuggoseg, amit a tesztben NEM akarunk igaziból elinditani.
 * Ezt fogjuk mockolni.
 */
public interface MessageSender {

    boolean send(String recipient, String message);
}
